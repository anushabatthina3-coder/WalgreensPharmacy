using Microsoft.EntityFrameworkCore;
using Pharmacy.Application;
using Pharmacy.Domain.Entities;

namespace Pharmacy.Infrastructure;

public class DrugRepository : IDrugRepository
{
    private readonly PharmacyDbContext _db;

    public DrugRepository(PharmacyDbContext db)
    {
        _db = db;
    }

    public Task<List<Drug>> GetAllAsync(CancellationToken ct = default) =>
        _db.Drugs.AsNoTracking().ToListAsync(ct);

    public Task<Drug?> GetByIdAsync(Guid id, CancellationToken ct = default) =>
        _db.Drugs.FindAsync(new object[] { id }, ct).AsTask();

    public async Task AddAsync(Drug drug, CancellationToken ct = default) =>
        await _db.Drugs.AddAsync(drug, ct);

    public Task SaveChangesAsync(CancellationToken ct = default) =>
        _db.SaveChangesAsync(ct);
}
