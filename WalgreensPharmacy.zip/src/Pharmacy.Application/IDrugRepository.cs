using Pharmacy.Domain.Entities;

namespace Pharmacy.Application;

public interface IDrugRepository
{
    Task<List<Drug>> GetAllAsync(CancellationToken ct = default);
    Task<Drug?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task AddAsync(Drug drug, CancellationToken ct = default);
    Task SaveChangesAsync(CancellationToken ct = default);
}
