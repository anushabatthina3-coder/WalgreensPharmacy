using Pharmacy.Domain.Entities;

namespace Pharmacy.Application;

public class DrugService
{
    private readonly IDrugRepository _repository;

    public DrugService(IDrugRepository repository)
    {
        _repository = repository;
    }

    public async Task<List<DrugDto>> GetCatalogAsync(CancellationToken ct = default)
    {
        var drugs = await _repository.GetAllAsync(ct);
        return drugs
            .OrderBy(d => d.Name)
            .Select(d => new DrugDto(d.Id, d.NdcCode, d.Name, d.Manufacturer, d.IsControlledSubstance, d.UnitPrice, d.ReorderThreshold))
            .ToList();
    }

    public async Task<DrugDto> CreateAsync(string ndcCode, string name, string manufacturer, bool isControlled, decimal unitPrice, int reorderThreshold, CancellationToken ct = default)
    {
        var drug = new Drug(ndcCode, name, manufacturer, isControlled, unitPrice, reorderThreshold);
        await _repository.AddAsync(drug, ct);
        await _repository.SaveChangesAsync(ct);

        return new DrugDto(drug.Id, drug.NdcCode, drug.Name, drug.Manufacturer, drug.IsControlledSubstance, drug.UnitPrice, drug.ReorderThreshold);
    }
}
