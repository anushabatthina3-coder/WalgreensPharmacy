namespace Pharmacy.Application;

public record DrugDto(
    Guid Id,
    string NdcCode,
    string Name,
    string Manufacturer,
    bool IsControlledSubstance,
    decimal UnitPrice,
    int ReorderThreshold);
