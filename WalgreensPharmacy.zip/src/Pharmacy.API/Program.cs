using Microsoft.EntityFrameworkCore;
using Pharmacy.Application;
using Pharmacy.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

// DbContext - using in-memory for simplicity, can be switched to SQL Server
builder.Services.AddDbContext<PharmacyDbContext>(options =>
    options.UseInMemoryDatabase("WalgreensPharmacy"));

builder.Services.AddScoped<IDrugRepository, DrugRepository>();
builder.Services.AddScoped<DrugService>();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Seed minimal catalog
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<PharmacyDbContext>();
    if (!db.Drugs.Any())
    {
        db.Drugs.Add(new Pharmacy.Domain.Entities.Drug("0002-8215", "Atorvastatin 20mg", "Generic", false, 0.25m, 50));
        db.Drugs.Add(new Pharmacy.Domain.Entities.Drug("0009-0775", "Metformin 500mg", "Generic", false, 0.10m, 100));
        db.SaveChanges();
    }
}

app.MapGet("/api/drugs", async (DrugService service, CancellationToken ct) =>
{
    var result = await service.GetCatalogAsync(ct);
    return Results.Ok(result);
});

app.MapPost("/api/drugs", async (DrugService service, DrugCreateRequest request, CancellationToken ct) =>
{
    var result = await service.CreateAsync(request.NdcCode, request.Name, request.Manufacturer,
        request.IsControlledSubstance, request.UnitPrice, request.ReorderThreshold, ct);

    return Results.Created($"/api/drugs/{result.Id}", result);
});

app.Run();

public record DrugCreateRequest(
    string NdcCode,
    string Name,
    string Manufacturer,
    bool IsControlledSubstance,
    decimal UnitPrice,
    int ReorderThreshold);
