namespace Pharmacy.Domain.Entities;

public class Drug
{
    public Guid Id { get; private set; } = Guid.NewGuid();
    public string NdcCode { get; private set; } = string.Empty; // National Drug Code
    public string Name { get; private set; } = string.Empty;
    public string Manufacturer { get; private set; } = string.Empty;
    public bool IsControlledSubstance { get; private set; }
    public decimal UnitPrice { get; private set; }
    public int ReorderThreshold { get; private set; }

    private Drug() { }

    public Drug(string ndcCode, string name, string manufacturer, bool isControlledSubstance, decimal unitPrice, int reorderThreshold)
    {
        if (string.IsNullOrWhiteSpace(ndcCode)) throw new ArgumentException("NDC is required", nameof(ndcCode));
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Name is required", nameof(name));
        if (unitPrice < 0) throw new ArgumentOutOfRangeException(nameof(unitPrice));
        if (reorderThreshold < 0) throw new ArgumentOutOfRangeException(nameof(reorderThreshold));

        NdcCode = ndcCode;
        Name = name;
        Manufacturer = manufacturer;
        IsControlledSubstance = isControlledSubstance;
        UnitPrice = unitPrice;
        ReorderThreshold = reorderThreshold;
    }
}
