namespace Pharmacy.Domain.Entities;

public class Prescription
{
    public Guid Id { get; private set; } = Guid.NewGuid();
    public string RxNumber { get; private set; } = string.Empty;
    public string PatientName { get; private set; } = string.Empty;
    public string DoctorNpi { get; private set; } = string.Empty; // US provider identifier
    public Guid DrugId { get; private set; }
    public int Quantity { get; private set; }
    public DateTime WrittenOn { get; private set; }
    public DateTime? FilledOn { get; private set; }

    private Prescription() { }

    public Prescription(string rxNumber, string patientName, string doctorNpi, Guid drugId, int quantity, DateTime writtenOn)
    {
        if (string.IsNullOrWhiteSpace(rxNumber)) throw new ArgumentException("Rx number required", nameof(rxNumber));
        if (string.IsNullOrWhiteSpace(patientName)) throw new ArgumentException("Patient required", nameof(patientName));
        if (string.IsNullOrWhiteSpace(doctorNpi)) throw new ArgumentException("Doctor NPI required", nameof(doctorNpi));
        if (quantity <= 0) throw new ArgumentOutOfRangeException(nameof(quantity));

        RxNumber = rxNumber;
        PatientName = patientName;
        DoctorNpi = doctorNpi;
        DrugId = drugId;
        Quantity = quantity;
        WrittenOn = writtenOn;
    }

    public void MarkFilled(DateTime when)
    {
        if (FilledOn is not null) throw new InvalidOperationException("Prescription already filled");
        if (when < WrittenOn) throw new ArgumentException("Fill date cannot be before written date", nameof(when));
        FilledOn = when;
    }
}
