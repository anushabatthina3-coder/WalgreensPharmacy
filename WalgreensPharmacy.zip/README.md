# Walgreens Pharmacy Management System (Demo)

This is a demo .NET 8 solution that represents an enterprise-style **Pharmacy Management API** similar to what a large US pharmacy chain (like Walgreens) might use for internal services.

The solution uses a layered architecture:

- **Pharmacy.Domain** – core entities (`Drug`, `Prescription`)
- **Pharmacy.Application** – DTOs and the `DrugService` application service
- **Pharmacy.Infrastructure** – EF Core `PharmacyDbContext` and `DrugRepository`
- **Pharmacy.API** – minimal API exposing `/api/drugs` endpoints

The API uses an in-memory database so it can run without any external setup.

> This project is for portfolio / learning purposes only and is not affiliated with Walgreens.

